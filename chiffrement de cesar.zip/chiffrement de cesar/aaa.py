def dechiffrer(text):
    tab_de_freq = [['e'], ['a'], ['i'], ['s'], ['t'], ['n'],['r'], ['u'], ['l'], ['o'], ['d'], ['m'],  ['p'], ['q'], ['c'], ['v'], ['b'], ['f'], ['j'], ['j'], ['h'], ['x'], ['z'], ['y'], ['k'], ['w']]
    table = []
    alphabet = "abcdefjhijklmnopqrstuvwxyz"
    esp = 0
    text = text.lower()







    for i in alphabet:
        position = ord(i) - 97
        l = []
        l.append(i)
        table.append(l)

    for caractere in text:

        if caractere == " ":
            esp += 1
            continue

        if caractere == "’":
            esp += 1
            continue

        position = ord(caractere) - 97

        a = int(table[position])
        a += 1




    length = len(text) - esp

    for i in table:
        i[1] = format(int(i[1]) / length)

    table.sort(key=lambda x: x[1])

    i = 0
    k = 0
    taille = 26
    while i < taille:
        k += ord(table[i]) - ord(tab_de_freq[i])
        i += 1

    k = int(k / taille)



    for key in range(k - 1, k + 2):

        message = ""

        for caractere in text:

            if caractere == " ":
                message += " "
                continue

            a = ord(caractere) - key

            if a < 79:

                message += chr(a + 26)

            else:
                message += chr(a)


        print("message clair :")
        print(message)
        print()



print(" le message que vous voulez déchiffrer :tm zwtm lm t’ibbiycivb uitqkqmcf ikbqn amzi rwcmxiz uizbqvqt am xmcb ycm t’ibbiycivb awqb cv lma xizbqkqxivba ic xzwbwkwtm qt xmcb umvbqz xmvlivbtm xzwbwkwtm wc umum vm xia lc bwcb acqdzm tma zmotma km bgxm l’ibbiycivb mab ixxmtmbzqkpmcz tma bzqkpmcza xiaaqna zmaxmkbmvb tm xzwbwkwtm uiqa qta maaiqmvb l’wjbmvqzxtca l ’qvnwzuibqwva ycm tm xzwbwkwtm vm tmcz xmzumb vwzuitmumvb tma bzqkpmcza ikbqnaitbmzmvb tm xzwbwkwtm mv kwcza mv maaigivb lm bzqkpmzqt mab bzma lqnnqkqtm lm oizivbqz ti amkczqbm lc agabmum aq ti xtcxizb lma xizbqkqxivbaawvb lma bzqkpmcza ikbqna uiqa xiznwqa qt mab xwaaqjtm xwcz tma xizbqkqxivba tmoqbquma lmlmbmkbmz yc’qt g i bzqkpmzqm ikbqdm lm bwcbm nikwv tma xzwbwkwtma lwqdmvb am xzmucvqzlm uivqmzm nqijtm kwvbzm ti bzqkpmzqm xiaaqdm")
msg="tm zwtm lm t’ibbiycivb uitqkqmcf ikbqn amzi rwcmxiz uizbqvqt am xmcb ycm t’ibbiycivb awqb cv lma xizbqkqxivba ic xzwbwkwtm qt xmcb umvbqz xmvlivbtm xzwbwkwtm wc umum vm xia lc bwcb acqdzm tma zmotma km bgxm l’ibbiycivb mab ixxmtmbzqkpmcz tma bzqkpmcza xiaaqna zmaxmkbmvb tm xzwbwkwtm uiqa qta maaiqmvb l’wjbmvqzxtca l ’qvnwzuibqwva ycm tm xzwbwkwtm vm tmcz xmzumb vwzuitmumvb tma bzqkpmcza ikbqnaitbmzmvb tm xzwbwkwtm mv kwcza mv maaigivb lm bzqkpmzqt mab bzma lqnnqkqtm lm oizivbqz ti amkczqbm lc agabmum aq ti xtcxizb lma xizbqkqxivbaawvb lma bzqkpmcza ikbqna uiqa xiznwqa qt mab xwaaqjtm xwcz tma xizbqkqxivba tmoqbquma lmlmbmkbmz yc’qt g i bzqkpmzqm ikbqdm lm bwcbm nikwv tma xzwbwkwtma lwqdmvb am xzmucvqzlm uivqmzm nqijtm kwvbzm ti bzqkpmzqm xiaaqdm"
dechiffrer(msg)
